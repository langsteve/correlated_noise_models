function GPS_time = SEC2GPST(total_gps_secs)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Utility function to convert gps time in seconds from Jan. 6, 1980 to a
% 2-element matrix of gps_week and gps_sec from beginning of week
%
% Input:  total_gps_seconds - gps_weeks*86400*7 + gps_secs (nx1) (seconds)
%             
% Output: GPS_time - [gps_weeks gps_secs] (nx2)
% 
% Where gps_secs is from the beginning of the week (midnight Saturday night).
%

GPS_time(:, 1) = floor(total_gps_secs ./ (86400 * 7));
GPS_time(:, 2) = total_gps_secs - GPS_time(:, 1) .* 86400 * 7;

end