function x_body = NED2BODY(x_ned, euler)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to transform a vector from the North-East-Down local-level frame to 
% a vehicle body frame. The body frame is transformed from the NED frame by a
% 3-2-1 euler angle rotation sequence. The rotation angles and axes of rotation are
% given by:
%
%     NED to NED' frame:    yaw about Down (3rd or z axis)
%     NED' to Body' frame:  pitch about E' (2nd or y axis)
%     Body' to Body frame:  roll about body-x axis (1st axis)
%
% Input:
%   x_ned - vector in NED frame (nx3) [North East Down]
%   euler - 3-2-1 Euler angle sequence from NED to body frame (radians)
%           This input can be either (1x3) or (nx3), where the 
%           1st col. is yaw, 2nd col. is pitch, 3rd col. is roll.
%           If 1x3, then then the same Euler angles are used for each
%           vector. [yaw pitch roll] 
% Output:
%   x_body  - transformed vector [xb, yb, zb] (nx3)
%

% Allocate the output matrix.
x_body = ones(size(x_ned, 1), 3) * inf;

% Compute the body vector a component at a time.
x_body(:, 1) = cos(euler(:, 1)) .* cos(euler(:, 2)) .* x_ned(:, 1) + ...
               sin(euler(:, 1)) .* cos(euler(:, 2)) .* x_ned(:, 2) - ...
               sin(euler(:, 2)) .* x_ned(:, 3);

x_body(:, 2) = (-sin(euler(:, 1)) .* cos(euler(:, 3)) + ...
               cos(euler(:, 1)) .* sin(euler(:, 2)) .* sin(euler(:, 3))) .* x_ned(:, 1) + ...
               (cos(euler(:, 1)) .* cos(euler(:, 3)) + ...
               sin(euler(:, 1)) .* sin(euler(:, 2)) .* sin(euler(:, 3))) .* x_ned(:, 2) + ...
               cos(euler(:, 2)) .* sin(euler(:, 3)) .* x_ned(:, 3);
             
x_body(:, 3) = (sin(euler(:, 1)) .* sin(euler(:, 3)) + ...
               cos(euler(:, 1)) .* sin(euler(:, 2)) .* cos(euler(:, 3))) .* x_ned(:, 1) + ...
               (-cos(euler(:, 1)) .* sin(euler(:, 3)) + ...
               sin(euler(:, 1)) .* sin(euler(:, 2)) .* cos(euler(:, 3))) .* x_ned(:, 2) + ...
               cos(euler(:, 2)) .* cos(euler(:, 3)) .* x_ned(:, 3);

end
