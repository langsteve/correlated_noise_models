function R_bn = ROT_BODY2NAV(phi, theta, psi)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------

R_bn = zeros(3, 3);
R_bn(1, 1) = cos(theta) * cos(psi);
R_bn(1, 2) = -cos(phi) * sin(psi) + sin(phi) * sin(theta) * cos(psi);
R_bn(1, 3) = sin(phi) * sin(psi) + cos(phi) * cos(psi) * sin(theta);
R_bn(2, 1) = cos(theta) * sin(psi);
R_bn(2, 2) = cos(phi) * cos(psi) + sin(phi) * sin(theta) * sin(psi);
R_bn(2, 3) = -sin(phi) * cos(psi) + cos(phi) * sin(psi) * sin(theta);
R_bn(3, 1) = -sin(theta);
R_bn(3, 2) = sin(phi) * cos(theta);
R_bn(3, 3) = cos(phi) * cos(theta);

end