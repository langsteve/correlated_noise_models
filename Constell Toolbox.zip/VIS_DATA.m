function [visible_data, I_pass] = VIS_DATA(mask, all_data, obscure_info, ...
                                    obscure_altitude)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Finds azimuth/elevation pairs passing the masking tests described in the mask
% variable. Returns only that data that passes the masking tests. 
%
% Input:
%   mask  - masking information (rad) (1x1, nx3, or nx4), default = 0;
%           1x1 form is minimum elevation only [min_el]
%           nx3 form is min elevation and azimuth bounds [min_el start_az stop_az]
%           nx4 form is elevation and azimuth bounds [min_el max_el start_az stop_az]
%           Azimuth start and stop are assumed to be clockwise.
%           Examples:
%         minimum elevation mask of 5 degrees (rad) (1x1) 
%              mask = .0873
%         minimum elevation and azimuth bound triples (nx3)
%              mask = [.0873   pi/2   pi;       % 5 deg min el, 90->180 azimuth
%                      .1745   pi    pi/4]      % 10 deg min el, 180->90 azimuth
%                                               % wraps through 0
%         elevation and azimuth bound quadruples
%              mask = [.0873  .5236  0    pi;    % 5->30 deg el, 0->180 azimuth
%                      .1745  pi/4   pi  2*pi]   % 10->45 deg el, 180->360 azimuth
%        Note: Set mask = -pi/2 to exclude data behind the earth
%   all_data - raw observation data [azimuth (rad), elevation (rad),
%                                    other corresponding data (optional)]
%              minimum size (nx2) up to (nxm)
%              valid values for azimuth are -2*pi to +2*pi
%              valid values for elevation are -pi/2 to +pi/2
%              Note: The corresponding data is optional and can be any data 
%                    corresponding to the az/el pairs (nxk) where k is the number
%                    of other data type included. Units are parameter dependent 
%                    and are not used within this function. Examples of data that
%                    might be included would be time, range, satellite number, etc.
%   obscure_info - contains information needed to determine whether the earth
%                  obscures the line-of-sight (nx3) [tangent_radius, alpha, beta].
%                  (meters, radians). Not used for visibility from a ground-based
%                  site. (Optional)
%                  Alpha is the angle between the x1 and x2 vectors sent to LOS.
%                  Beta is the angle between the x1 vectors and the radius to the
%                  tangent point of the los vectors.
%                  An observation is obscured if the tangent radius is below the 
%                  users tolerance, and alpha is greater than beta. 
%   obscure_altitude - Altitude above earth to include in earth obscuration 
%                      (meters) (nx1). Default = 0 meters. Not used for visibility
%                      from a ground-based site. (Optional)
% Output:
%   visible_data - all_data that passed the masking test and is not obscured by the
%                  Earth (jxm)
%   I_pass       - index to data that passed the masking test (jx1)
%

az = all_data(:, 1);
el = all_data(:, 2);
% define the return matrix of passing pairs as null ([])
I_pass = [];

% Verify that all azimuth definitions are from 0 -> 360 (not -180 -> 180)
I_az_negative = find(az < 0);                      % find all negative azimuths
az(I_az_negative) = az(I_az_negative) + 2 * pi;    % and convert to positive

if size(mask,2) == 1         % only an elevation mask is used
    I_pass = find(el >= mask); % find all the elevations above the elevation mask

% else if we have an elevation and azimuth range to evaluate
elseif size(mask, 2) == 3
    num_mask_pairs = size(mask, 1);    % find out how many el/az pairs we have

    for i = 1 : num_mask_pairs 
        if mask(i, 2) > mask(i, 3)
            I_pass_new = find(el >= mask(i, 1) & (az >= mask(i, 2) | az <= mask(i, 3)));
        else  
            I_pass_new = find(el >= mask(i, 1) & az >= mask(i, 2) & az <= mask(i, 3));
        end
        I_pass = [I_pass; I_pass_new];
    end

    % sort back to the original ordering
    I_pass = sort(I_pass);

elseif size(mask, 2) == 4
    num_mask_pairs = size(mask, 1);    % find out how many el/az pairs we have

    for i = 1 : num_mask_pairs 
        if mask(i, 3) > mask(i, 4)
            I_pass_new = find(el >= mask(i, 1) & el <= mask(i, 2) & ...
                             (az >= mask(i, 3) | az <= mask(i, 4)));
        else  
            I_pass_new = find(el >= mask(i, 1) & el <= mask(i, 2) & ...
                              az >= mask(i, 3) & az <= mask(i, 4));
        end

        I_pass = [I_pass; I_pass_new];
    end

    % sort back to the original ordering
    I_pass = sort(I_pass);

else
    fprintf('Unknown mask input format.  See help on vis_data for details.\n');

end 

% Check for whether observation is obscured by Earth
% Observation is obscured if the tangent altitude is below altitude threshold
% and alpha > beta
if nargin >= 3
    i_vis = find(obscure_info(I_pass, 1) >= obscure_altitude ...
                 | obscure_info(I_pass, 2) <= obscure_info(I_pass, 3));

    if any(i_vis)
        I_pass = I_pass(i_vis);
        I_pass = sort(I_pass);
    end
end

% sort out the visible data and indices
visible_data = all_data(I_pass, :);

end
