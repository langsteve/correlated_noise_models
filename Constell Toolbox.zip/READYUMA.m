function alm = READYUMA(filename, rollover_flag)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Read in YUMA formatted GPS almanac.
%
% Inputs:
%   filename - Name of almanac file to read.
%   
%   rollover_flag - Flag indicating the number of GPS week rollovers that have
%                   occured (1st rollover on August 22, 1999). GPS time is kept as
%                   total number of GPS weeks (weeks go beyond 1024). The GPS week in
%                   the almanac will be replaced with the GPS_week + 1024 for a
%                   rollover flag of 1.

% Outputs:
%   gps_alm - GPS almanac data matrix for all the GPS satellites found in the
%             specified almanac file. (nx13)
%
% Note: Yuma almanac format is as follows:
%       [sv_num, health, ecc, GPS_sec, inc, asc_node_rate, sqrt_a,
%        long of asc. node at weekly epoch, perigee, mean_anomaly, Af0, Af1, GPS_week]
%        with units of rad, s, and m^.5

inputfile = filename;
fid = fopen(inputfile, 'r');

% check for a valid file ID for the GPS almanac
if fid < 0     
    fprintf('Unable to open the almanac file %s. \n', inputfile(1,:))
    fprintf('Check that the file name and path are correct.\n');
    fprintf('No GPS almanac will be returned\n')
    alm = [];
end

% Read through the file and fill in the almanac matrix.

err_msg = blanks(0);          % Set the error message to blank.
end_of_file = 0;              % Set the end of file flag to 0.

read_error = 0;               % Set a flag if a read error has occurred.
num_lines_per_almanac = 13;   % 15 lines for each sat. in the almanac file.

satellite_count = 1;          % Counter with the the current satellite count.
almanac_head = fgetl(fid);    % Get the header line for the first satellite.

if ~ischar(almanac_head)       % Does the line read contain a string.
    if almanac_head == -1     % Is there an end of file on the first line.
        end_of_file = 1;
        read_error = 1;       % Read error in the given almanac file.
    end
end

clear alm                     % Clear any previous almanacs.

while end_of_file == 0 && read_error == 0
    for i = 1 : num_lines_per_almanac
        almanac_line = fgetl(fid);      % Get the next line from the almanac file.

        if almanac_line == -1           % Is there an end of file.
            end_of_file = 1;            % Set end of file flag.
        else
            I_colon = find(almanac_line == ':');  % Find the colon in the line.
            if isempty(I_colon)   				  % Search for a '('.
                I_colon = find(almanac_line == ')');
            end
            I_end = size(almanac_line, 2);        % Find the end of the line.

            if any(I_colon) && I_end > 3          % Valid almanac line.
                [alm(satellite_count, i), ~, err_msg] = ...
                    sscanf(almanac_line(I_colon + 1 : I_end), '%f');
            else
                read_error = 1;                   % Set the read error flag.
                keyboard
            end

            if ~isempty(err_msg)                  % Verify the read was successfull.
                read_error = 1;                   % Set no_read_error flag.
                i = num_lines_per_almanace + 1;   % Set loop parameter to exit loop.
            end
        end
    end

    almanac_tail = fgetl(fid);       % get the tailer line for this satellite.
    almanac_head = fgetl(fid);       % get the header line for next satellite.

    if ~ischar(almanac_tail) || ~ischar(almanac_head)
        if almanac_head == -1 || almanac_tail == -1      % Is there an end of file.
            end_of_file = 1;
        end
    end
    satellite_count = satellite_count + 1;  % Increment the satellite counter.
end
fclose(fid);  % Close the file.

if rollover_flag ~= 0
    alm(:, 13) = alm(:, 13) + rollover_flag * 1024;
end

end
