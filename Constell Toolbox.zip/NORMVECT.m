function [x_norm, x_mag] = NORMVECT(x)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to normalize n-dimensional vectors to have length of 1.
%
% Input:
%   x      - vector to be normalized  (n x m)
% Output:
%   x_norm - normalized vector, magnitude = 1, same direction as x (n x m)
%   x_mag  - magnitude of the vector (n x 1)


% Initialize the output variable to be all zeros.
x_norm = zeros(size(x));

sum = zeros(size(x, 1), 1);
for i = 1 : size(x, 2)
    sum = sum + x(:, i) .^ 2;
end
x_mag = sqrt(sum);

% Find all of the magnitudes with non-zero length.
I_non_zero = find(x_mag ~= 0);                   
if any(I_non_zero)
    for i = 1 : size(x, 2)
        x_norm(I_non_zero, i) = x(I_non_zero, i) ./ x_mag(I_non_zero);
    end
end

