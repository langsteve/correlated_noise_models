function lla = ECEF2LLA(x_ecef, constants)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to compute geodetic latitude, longitude, and height from ECEF coordinates.

% Input:
%   x_ecef - ECEF position in meters (nx3) [x_ecef, y_ecef, z_ecef]

% Output:
%   lla    - geodetic lat, lon, and height (nx3) [lat, lon, height]
%            lat and lon are in rad (mod 2*pi),
%            height is meters above the WGS-84 ellipsoid

% WGS-84 constants
RE =  constants.semi_major_axis;  % Equatorial radius of Earth, semi-major axis (m)
ecc = constants.eccentricity;     % Eccentricity
b = constants.semi_minor_axis;    % Ellipsoid semi-minor axis

% Initialize the output variables.
lla = zeros(size(x_ecef, 1), 3);

tol = 1e-14;            % Set a tight tolerance on the change in lat (rad)
max_iter = 150;         % Set maximum iterations
m = 1;                  % Set first iteration
dlat = 1;               % Set the dlat value high for first iteration

e2 = ecc ^ 2;                                     % eccentricity squared.
p = sqrt(x_ecef(:, 1) .^ 2 + x_ecef(:, 2) .^ 2);  % Auxiliary quantity.  
lat = atan2(x_ecef(:, 3), p .* (1 - e2));         % Initial estimate of the latitude.

lla(:, 2) = atan2(x_ecef(:, 2), x_ecef(:, 1));    % Compute longitude.

% Loop until the process has converged or maximum iterations are exceeded.
while m < max_iter
    test = max(abs(dlat));
    if test < tol
        return
    end

    % Compute the radius of curvature in the prime vertical for this latitude.
    n = RE ^ 2 ./ sqrt(RE ^ 2 * cos(lat) .^ 2 + b ^ 2 * sin(lat) .^ 2);
    lla(:, 3) = (p ./ cos(lat)) - n;         % ellipsoidal height estimate.
    
    % New estimate of latitude.
    newlat = atan2(x_ecef(:, 3), p .* (1 - e2 .* (n ./ (n + lla(:, 3)))));
    dlat = abs(lat - newlat); % Compute change in latitude for this iteration.
    lat = newlat;             % Update the latitude.
    lla(:, 1) = lat;          % Set the return value to the last loop value.
    m = m + 1;                % Increase the loop counter.
end

