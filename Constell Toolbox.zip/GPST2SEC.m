function total_gps_seconds = GPST2SEC(GPS_time)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Utility function to convert a GPS time structure to pure seconds. This is useful
% when generating time intervals that may cross a week boundary.
%
%   Input:  GPS_time = [gps_weeks gps_secs (from beginning of week)]
%            valid GPS_week values are 1-3640 (years 1980-2050)
%            valid GPS_sec values are 0-604799
%
%   Output: total_gps_seconds = gps_weeks * 86400 * 7 + gps_secs
%

total_gps_seconds = GPS_time(:, 1) .* 86400 * 7 + GPS_time(:, 2);

end