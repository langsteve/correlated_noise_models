function gps_ephem = ALM2GEPH(alm)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% This function converts from an almanac format to a GPS ephemeris format.
%
% Input:
%   alm - Yuma almanac format (nx13), with columns of
%                 [ID, health, e, t0, i, asc_rate, sqrt(a), long. of asc_node
%                 at GPS week epoch, perigee, M, af0, af1, week]
%                 units are seconds, meters, and radians
% Output:
%    gps_ephem - ephemeris matrix for all satellites (nx24), with columns of
%                 [prn, M0, delta_n, e, sqrt_a, long. of asc_node at GPS week epoch,
%                 i, perigee, ra_rate, i_rate, Cuc, Cus, Crc, Crs, Cic, Cis, Toe,
%                 IODE, GPS_week, Toc, Af0, Af1, Af2, perigee_rate]

%                 Ephemeris parameters are from ICD-GPS-200 with the exception of
%                 perigee_rate. The gps_ephem will be filled with inf values for any
%                 almanac element set that is out bounds.

% Allocate the gps_ephem matrix.
gps_ephem = ones(size(alm, 1), 22) * inf;

gps_ephem(:, 1) = alm(:, 1);                % SV numbers
gps_ephem(:, 2) = alm(:, 10);               % Mean anomaly
gps_ephem(:, 3) = zeros(size(alm(:, 1)));   % mean motion correction
gps_ephem(:, 4) = alm(:, 3);                % eccentricity
gps_ephem(:, 5) = alm(:, 7);                % sqrt semi-major axis
gps_ephem(:, 6) = alm(:, 8);                % acsending node
gps_ephem(:, 7) = alm(:, 5);                % inclination
gps_ephem(:, 8) = alm(:, 9);                % perigee
gps_ephem(:, 9) = alm(:, 6);                % ra_rate
gps_ephem(:, 10) = zeros(size(alm(:, 1)));  % i_rate
gps_ephem(:, 11) = zeros(size(alm(:, 1)));  % Cuc
gps_ephem(:, 12) = zeros(size(alm(:, 1)));  % Cus
gps_ephem(:, 13) = zeros(size(alm(:, 1)));  % Crc
gps_ephem(:, 14) = zeros(size(alm(:, 1)));  % Crs
gps_ephem(:, 15) = zeros(size(alm(:, 1)));  % Cic
gps_ephem(:, 16) = zeros(size(alm(:, 1)));  % Cis
gps_ephem(:, 17) = alm(:, 4);               % toe (time of ephemeris)
gps_ephem(:, 18) = zeros(size(alm(:, 1)));  % IODE
gps_ephem(:, 19) = alm(:, 13);              % GPS week
gps_ephem(:, 20) = alm(:, 4);               % Toc (time of clock)
gps_ephem(:, 21) = alm(:, 11);              % Af0 (clock term)
gps_ephem(:, 22) = alm(:, 12);              % Af1 (clock term)
gps_ephem(:, 23) = zeros(size(alm(:, 1)));  % Af2 (clock term)
gps_ephem(:, 24) = zeros(size(alm(:, 1)));  % perigee rate (J2)

end