function leap_sec = UTC2LEAP(UTC_time)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Determines the number of leap seconds of offset between GPS and UTC time.
%
% Input:  
%   UTC_time - matrix of the form [year month day hour minute second]
%               with 4-digit year (1980), nx6 matrix
% Output: 
%   leap_sec - leap seconds relating UTC to GPS time


% Verify that the leapsecs.dat file exist.
if exist('leapsecs.dat') ~= 2
    fprintf('Unable to open the data file LEAPSECS.DAT.\n');
    fprintf('Verify that the file is in the Matlab path.\n');
    if DEBUG_MODE == 1
        fprintf('Error msg: Unable to open LEAPSECS.DAT.\n')
    else 
        error('Unable to open LEAPSECS.DAT.');
    end
end

% load leap seconds data file (leapsecs.dat)
load leapsecs.dat

% verify that the leapsecs loaded has the correct number of columns
if size(leapsecs, 2) ~= 7
    fprintf('Error in LEAPSECS.DAT file.\n');
    fprintf('There were %d columns in the file.  There should be 7 columns.\n', size(leapsecs, 2));
    fprintf('Verify the Matlab path is correct and the correct version of LEAPSECS.DAT is in use.\n');
    if DEBUG_MODE == 1
      fprintf('Error msg: Invalid LEAPSECS.DAT file.\n')
    else 
      error('Invalid LEAPSECS.DAT file.');
    end
end
    
n_leaps = size(leapsecs, 1);   % number of leap seconds given in the data file

% search leapsecs for each of the time given in UTC_time. Only have to search based on 
% year and month since the leap seconds are added at the beginning of Jan and July.                     
for jjj = n_leaps : -1 : 1
    I_n = find(UTC_time(:, 1) + UTC_time(:, 2) / 12 < leapsecs(jjj, 1) + leapsecs(jjj, 2) / 12);
    leap_sec(I_n) = ones(size(I_n, 1), 1) * leapsecs(jjj, 7) - 1;
end

I_l = find(UTC_time(:, 1) + UTC_time(:, 2) / 12 >= leapsecs(n_leaps, 1) + leapsecs(n_leaps, 2) / 12);
leap_sec(I_l) = ones(size(I_l, 1), 1) * leapsecs(n_leaps, 7);

% Reshape leap_sec so that it is nx1
leap_sec = leap_sec';

end
