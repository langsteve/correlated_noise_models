function output = GrovesGravityModel(LLAPosition, constants)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


mu = 3.986004418E+014;                       % m^3/sec^2  (page 71 in Groves).
J2 = 1.082627E-03;                           %            (page 72 in Groves).
R0 = constants.semi_major_axis;              % meters     (page 56 in Groves).
w_ie = [0; 0; constants.earth_rate];         % rad/sec    (page 67 in Groves).

N = size(LLAPosition, 1);
output = zeros(N, 3);
for index = 1 : N
    Latitude = LLAPosition(index, 1);
    Longitude = LLAPosition(index, 2);
    C_en = EcefToNedRotationMatrix(Latitude, Longitude);
    
    EcefPosition = ConvertLLAToECEF(LLAPosition(index, :), constants);
    NormEcefPosition = norm(EcefPosition);
    NormalizedZComponent = EcefPosition(3) / NormEcefPosition;
    
    % From the bottom of page 71 in Groves: "when working in an inertial reference
    % frame, only the gravitational acceleration is required. This can be calculated
    % at varying heights using [equation (2.142) on page 72]. Thus, the formula in
    % Groves already accounts for the variation of gravity with height.
    
    xi(1, 1) = (1 - 5 * NormalizedZComponent ^ 2) * EcefPosition(1);
    xi(2, 1) = (1 - 5 * NormalizedZComponent ^ 2) * EcefPosition(2);
    xi(3, 1) = (3 - 5 * NormalizedZComponent ^ 2) * EcefPosition(3);
    gamma_ib_e = -mu / NormEcefPosition ^ 3 * (EcefPosition' + ...
                 (3/2) * J2 * (R0 / NormEcefPosition) ^ 2 * xi);
    
    CentripetalAcceleration = cross(w_ie, cross(w_ie, EcefPosition'));
    gamma_ib_n = C_en * (gamma_ib_e - CentripetalAcceleration);
    output(index, :) = gamma_ib_n;

end

end