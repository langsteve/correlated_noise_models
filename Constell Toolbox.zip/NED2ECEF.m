function x_ecef = NED2ECEF(x_ned, ref_lla)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to convert vectors from NED (North-East-Down) coordinates to 
% ECEF (Earth-Centered-Earth-Fixed).
%
% Input:
%   x_ned   - NED position in meters [x_ned, y_ned, z_ned] (nx3)
%   ref_lla - reference lat, lon, and hgt for NED coordinate system base
%             lat and lon in rad, hgt in meters
%             ref_lla must have dimensions of 1x3 or nx3 [lat lon hgt]
%                 or 1x2 or nx2 [lat lon]
%              (Note:  hgt not used in this routine).
%              valid latitudes are -pi/2 -> pi/2
%              valid longitudes are -pi -> 2*pi
%
% Output:
%   x_ecef  - ECEF position in meters [x_ecef, y_ecef, z_ecef](nx3)
%

% Allocate the output x_ecef vector and fill it with inf.
% Values for valid ref_lla will be filled in the following code.
x_ecef = ones(size(x_ned)) * inf;

% compute the NED vector a component at a time
x_ecef(:, 1) = -x_ned(:, 1) .* sin(ref_lla(:, 1)) .* cos(ref_lla(:, 2)) - ...
                x_ned(:, 2) .* sin(ref_lla(:, 2)) - ...
                x_ned(:, 3) .* cos(ref_lla(:, 1)) .* cos(ref_lla(:, 2));
             
x_ecef(:, 2) = -x_ned(:, 1) .* sin(ref_lla(:, 1)) .* sin(ref_lla(:, 2)) + ...
                x_ned(:, 2)  .* cos(ref_lla(:, 2)) - ...
                x_ned(:, 3) .* cos(ref_lla(:, 1)) .* sin(ref_lla(:, 2));
             
x_ecef(:, 3) = x_ned(:, 1) .* cos(ref_lla(:, 1)) - x_ned(:, 3) .* sin(ref_lla(:, 1));

end
