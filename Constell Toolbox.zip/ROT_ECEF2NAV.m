function C_en = ROT_ECEF2NAV(L, lam)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


C_en = zeros(3, 3);
C_en(1, 1) = -sin(L) * cos(lam);
C_en(1, 2) = -sin(L) * sin(lam);
C_en(1, 3) = cos(L);
C_en(2, 1) = -sin(lam);
C_en(2, 2) = cos(lam);
C_en(2, 3) = 0;
C_en(3, 1) = -cos(L) * cos(lam);
C_en(3, 2) = -cos(L) * sin(lam);
C_en(3, 3) = -sin(L);

end