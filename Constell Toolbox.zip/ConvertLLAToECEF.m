function EcefPosition = ConvertLLAToECEF(LLAPosition, constants)

%-------------------------------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and U.S. DoD contractors only
% (critical technology)(June 26, 2019). Other requests shall be referred to (PNT Program Office).
%-------------------------------------------------------------------------------------------------------------

%-------------------------------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No. FA8702-19-C-0001, and is subject to
% the Rights in Noncommercial Computer Software and Noncommercial Computer Software Documentation Clause
% 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%-------------------------------------------------------------------------------------------------------------


SemiMajorAxis = constants.semi_major_axis;
SemiMinorAxis = constants.semi_minor_axis;

Latitude = LLAPosition(:, 1);
Longitude = LLAPosition(:, 2);
Height = LLAPosition(:, 3);

EcefPosition = zeros(size(LLAPosition, 1), 3);
n = SemiMajorAxis ^ 2 ./ sqrt(SemiMajorAxis ^ 2 * cos(Latitude) .^ 2 + SemiMinorAxis ^ 2 * sin(Latitude) .^ 2);
EcefPosition(:, 1) = (n + Height) .* cos(Latitude) .* cos(Longitude);
EcefPosition(:, 2) = (n + Height) .* cos(Latitude) .* sin(Longitude);
EcefPosition(:, 3) = ((SemiMinorAxis ^ 2 / SemiMajorAxis ^ 2) * n + Height) .* sin(Latitude);

end