function skew_sym_mtrx = SKEW_SYMMETRIC(x)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


skew_sym_mtrx = [0, -x(3), x(2)
                 x(3), 0, -x(1)
                 -x(2), x(1), 0];

end