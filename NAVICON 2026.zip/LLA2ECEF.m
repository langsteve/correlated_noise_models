function x_ecef = LLA2ECEF(x_lla)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


a = 6378137;               % Length of semi-major axis of WGS-84 ellipsoid (m).
ecc = 0.081819194069145;   % Eccentricity
b = a * sqrt(1 - ecc ^ 2); % Ellipsoid semi-minor axis

lat = x_lla(:, 1);
lon = x_lla(:, 2);
hgt = x_lla(:, 3);

x_ecef = zeros(size(x_lla,1),3);
n = a ^ 2 ./ sqrt(a ^ 2 * cos(lat) .^ 2 + b ^ 2 * sin(lat) .^ 2);
x_ecef(:, 1) = (n + hgt) .* cos(lat) .* cos(lon);
x_ecef(:, 2) = (n + hgt) .* cos(lat) .* sin(lon);
x_ecef(:, 3) = ((b ^ 2 / a ^ 2) * n + hgt) .* sin(lat);

end