function x_ned = ECEF2NED(x_ecef, ref_lla)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to convert vectors from ECEF (Earth-Centered-Earth-Fixed) to NED
% (North-East-Down) coordinates.

% Input:
%   x_ecef  - ECEF position in meters (nx3) [x_ecef, y_ecef, z_ecef]
%   ref_lla - Reference lat, lon, and hgt for NED coordinate system base.
%             Latitude and longitude are in radians.
%             'ref_lla' must have dimensions of (1x3 or nx3) or (1x2 or nx2)
%             [lat lon hgt] or [lat lon]

%             Note: hgt is not used in this function.
%             Valid latitudes: (-pi/2 -> pi/2). Valid longitudes are (-pi -> 2*pi).

% Output:
%   x_ned  - NED position in meters (nx3) [x_ned, y_ned, z_ned]

% Allocate the x_ned output matrix to all inf. Valid x_ned's will be filled in the
% following code.
x_ned = ones(size(x_ecef)) * inf;

% Compute the NED vector one component at a time.
x_ned(:, 1) = -x_ecef(:, 1) .* sin(ref_lla(:, 1)) .* cos(ref_lla(:, 2)) - ...
               x_ecef(:, 2) .* sin(ref_lla(:, 1)) .* sin(ref_lla(:, 2)) + ...
               x_ecef(:, 3) .* cos(ref_lla(:, 1));

x_ned(:, 2) = -x_ecef(:, 1) .* sin(ref_lla(:, 2)) + ...
               x_ecef(:, 2) .* cos(ref_lla(:, 2));

x_ned(:, 3) = -x_ecef(:, 1) .* cos(ref_lla(:, 1)) .* cos(ref_lla(:, 2)) - ...
               x_ecef(:, 2) .* cos(ref_lla(:, 1)) .* sin(ref_lla(:, 2)) - ...
               x_ecef(:, 3) .* sin(ref_lla(:, 1));

end
