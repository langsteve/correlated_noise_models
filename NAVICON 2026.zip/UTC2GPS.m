function [GPS_week, GPS_sec, GPS_day] = UTC2GPS(UTC_time, leap_sec)

%-------------------------------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and U.S. DoD contractors only
% (critical technology)(June 26, 2019). Other requests shall be referred to (PNT Program Office).
%-------------------------------------------------------------------------------------------------------------

%-------------------------------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No. FA8702-19-C-0001, and is subject to
% the Rights in Noncommercial Computer Software and Noncommercial Computer Software Documentation Clause
% 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%-------------------------------------------------------------------------------------------------------------


% [GPS_week, GPS_sec, GPS_day] = utc2gps(UTC_time,leap_sec);
%
%                          OR
%
% GPS_time = utc2gps(UTC_time,leap_sec);

% where GPS_time = [GPS_week GPS_sec] (nx2)

% Converts a UTC time matrix to the equivalent time in GPS weeks, GPS seconds, and GPS days (GPS time started
% at 00:00:00 6 JAN 1980)

% Input:
%   UTC_time - matrix of the form [year month day hour minute second] (nx6) with 4-digit (1980) or 2-digit
%              (80) years, valid years are 1980 - 2079 (2-digit 80-79)
%   leap_sec - leap seconds applied to UTC relative to GPS (optional)
%              can be a 1x1 or an nx1, if not entered the function will use a look-up table to determine the
%              number of leap seconds
% Output:
%   GPS_week - GPS week (nx1) (if 0 or 1 output parameters are used, this is filled with [GPS_week GPS_sec]
%              (nx2).  See the alternative calling option from above.
%   GPS_sec  - seconds into the week measured from Sat/Sun midnight (nx1)
%   GPS_day  - days since the beginning of GPS time (optional) (nx1)

%------------------------------------------------------------------------------------
%------------------------------------------------------------------------------------

% Days in full months for leap year.
leapdays = [0 31 60 91 121 152 182 213 244 274 305 335];

% Days in full months for standard year.
noleapdays = [0 31 59 90 120 151 181 212 243 273 304 334];

% Leap year flag. Determine which input years are leap years.
leap_year = ~rem((UTC_time(:, 1) - 1980), 4);     
I_leap = find(leap_year == 1);                % find leap years
I_no_leap = find(leap_year == 0);             % find standard years

% Round the first column of the almanac to get integer satellite numbers.
a_round = ceil(UTC_time(:, 2));
d_diff = a_round - UTC_time(:, 2);
I_diff_non_zero = find(d_diff ~= 0);
if ~isempty(I_diff_non_zero)
    UTC_time(I_diff_non_zero, 2) = a_round(I_diff_non_zero);
    fprintf('Non-integer months numbers have been rounded up in UTC2GPS.\n')
end

% Generate a matrix that has the days per completed month for both leap and standard years.
if any(I_leap)
    dayspermonth(I_leap) = leapdays(UTC_time(I_leap, 2));
end

if any(I_no_leap)
    dayspermonth(I_no_leap) = noleapdays(UTC_time(I_no_leap, 2));
end

% Compute the number of leap days encountered in past years. Need to add one to the fix computation to get the
% year correct.
leapyrs = fix((UTC_time(:, 1) - 1980) ./ 4) + eval('~leap_year');

% Compute the number of days in completed years since 1980.
gpsday = (UTC_time(:, 1) - 1980) .* 365 + leapyrs;
                               
% Add the number of days for each completed month.
gpsday = gpsday + dayspermonth';

% Add the number of days for each completed day (which is 1 less than the current day).
gpsday = gpsday + (UTC_time(:, 3) - 1);

% Add the fraction of days for each completed hour (hour/24). Seconds into the current day (avoids round-off
% errors).
gpssec = UTC_time(:, 4) .* 3600; 

% Add the fraction of days for each completed minute (minute/1440).
gpssec = gpssec + UTC_time(:, 5) .* 60;

% Add the fraction of days each completed second (second/86400).
gpssec = gpssec + UTC_time(:, 6);

% Subtract 5 days because the starting date is 00:00 6 January 1980
gpsday = gpsday - 5; 

GPS_day = gpsday;

% Formal return parameter 'GPS_week.'
GPS_week = fix(GPS_day ./ 7);
days_into_week = floor(rem(GPS_day, 7));

% Add leap seconds to the gps time.
GPS_sec = days_into_week * 86400 + gpssec + leap_sec;

% Check to make sure the leap seconds don't force a week rollover.
I_next = find(GPS_sec >= 86400 * 7);
if any(I_next)
    GPS_week(I_next) = GPS_week(I_next) + 1;
    GPS_sec(I_next) = GPS_sec(I_next) - 86400 * 7;
end

% Check the output arguments. If the output requested is length 0 to 1, return GPS week and GPS seconds in a
% single vector.
if nargout == 0 || nargout == 1
    GPS_week = [GPS_week GPS_sec'];
end

% Return the GPS week, GPS seconds into the week, and the number of completed days (GPS). Formal return
% parameter GPS days since Jan 6 1980.
if nargout == 3
    GPS_day = GPS_week * 7 + GPS_sec / 86400;
end

end
