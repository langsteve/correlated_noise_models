function baseline_estimation_covariane_analysis()

close all;
% addpath('C:\Users\slangel\Desktop\Mon Jul 27 13-33-03 2026\Users\slangel\Documents\UtilityFunctions');

%-- Constants.
speed_of_light = 2.99792458E+08;                        % In meters/sec.

%-- Configurable and simulation control parameters.
sampling_interval = 1.0;                                         % In seconds.
filter_duration = 60;                                            % In seconds.
reference_station_lla = [40.69 * pi/180, -74.17 * pi/180, 0];    % Newark airport.
start_time_utc = [2020, 3, 1, 17, 0, 0];                         % [year month day hour minute second].
leap_seconds = 18;                                               % 18 leap seconds as of 3-1-2020.
elevation_mask = 10 * pi / 180;                                  % In degrees.

C_en = EcefToNedRotationMatrix(reference_station_lla(1), reference_station_lla(2));

%-- Mathieu configurable parameters.
Ron = 0.00001;                  % Rate of onset per unit time.   
tsCoast = 2;                    % Start time of exposure.
AL = 10;                        % Alert limit on state of interest
PFAreq = 1E-04;
PHMIreq = 1E-05;

tVec = 0 : sampling_interval : filter_duration;  % Time vector.
nT = length(tVec);
kFA = norminv(1 - PFAreq/2);
kHMI = norminv(1 - PHMIreq/2);

%-- Load ephemeris file corresponding to baseline 24-slot GPS constellation.
ephemeris = load('DO229_GPS_ephemeris.mat').ephemeris;

%-- Generate satellite position vectors.
start_time_gps = UTC2GPS(start_time_utc, leap_seconds);
end_time_gps = start_time_gps + [0, filter_duration];
[~, PRN, sv_ecef_position, ~] = PROPGEPH(ephemeris, start_time_gps, end_time_gps, sampling_interval);

%-- Line-of-sight unit vectors from the reference receiver to the satellite.
reference_station_ecef = LLA2ECEF(reference_station_lla);
LOS_vector_ecef = sv_ecef_position - reference_station_ecef;
LOS_unit_vector_ecef = LOS_vector_ecef ./ vecnorm(LOS_vector_ecef')';

%-- Determine index to data that is above the elevation mask.
LOS_vector_ned = ECEF2NED(LOS_vector_ecef, reference_station_lla);
[azimuth, elevation] = NED2AZEL(LOS_vector_ned);
[~, I_pass] = VIS_DATA(elevation_mask, [azimuth elevation]);

%-- Only keep data for satellites above the elevation mask.
LOS_unit_vector_ecef = LOS_unit_vector_ecef(I_pass, :);
PRN = PRN(I_pass);

%-- Only keep data for SVs that are visible for the entire simulation.
total_num_epochs = filter_duration / sampling_interval + 1;
all_prn = unique(PRN);
prn_keep = [];
ind_remove = [];
for idx = 1 : length(all_prn)
    index_current_prn = find(PRN == all_prn(idx));
    if length(index_current_prn) == total_num_epochs
        prn_keep = [prn_keep; all_prn(idx)];
    else
        ind_remove = [ind_remove; index_current_prn];
    end
end
LOS_unit_vector_ecef(ind_remove, :) = [];
num_sv = length(prn_keep);

% alpVec = [0; 0; 1; zeros(2 + 2 * num_sv, 1)];     % state of interest (Position)
alpVec = [C_en(:, 3); zeros(2 + 2 * num_sv, 1)];     % state of interest (Position)

%-------------------------------------------------------------------------------------------------------------
% Receiver clock error model. We assume the GPS receiver has an OCXO, which has the Allan variance parameters
% h_0 = 2E-25 and h_2 = 6E-25 (see Table 9.1 on page 327 in [3]). The Allan variance parameters are translated
% to power spectral densities for the two-state clock model through: S_freq ~ 2 * pi ^ 2 * h_2 and
% S_phase ~ h_0/2. PSDs are converted to length units by multiplying by the speed of light squared.
    
% References
% [3] R. G. Brown and P. Y.C. Hwang, "Introduction to Random Signals and Applied Kalman Filtering," 4th ed.
 %    Danvers, MA: John Wiley & Sons, Inc., 2012, pp. 326-327.

S_bias = speed_of_light ^ 2 * 1E-25;     % m^2/Hz
S_drift = speed_of_light ^ 2 * 1.2E-23;  % (m/s)^2/Hz

%-- Discrete time process noise covariance matrix for clock model.
Q_clk(1, 1) = S_bias * sampling_interval + 1/3 * S_drift * sampling_interval ^ 3;
Q_clk(1, 2) = 1/2 * S_drift * sampling_interval ^ 2;
Q_clk(2, 1) = Q_clk(1, 2);
Q_clk(2, 2) = S_drift * sampling_interval;

%-- Transition matrix for 2-state clock model and number of KF states.
F_clk = [1, sampling_interval; 0 1];
num_KF_states = 3 + 2 + 2 * num_sv;

%-- SD CP measurement error model parameters. All variances are in units of meters^2.
wgn_variance = 0.25;
multipath_variance = 1.5;
multipath_time_constant = 180;
alpha = exp(-sampling_interval / (multipath_time_constant));

%-- Initial covariance matrix for the primary KF. The initial variance for each relative position state is
%-- (2 meters)^2 and for each SD cycle ambiguity state it is (5/sqrt(2) meters)^2. The initial covariance
%-- matrix for the DD cycle ambiguities includes the DD transformation matrix.
P_delta_x = eye(3) * 4;
P_SD_rcvr_clk = [10 ^ 2, 0; 0, 2 ^ 2];
P_SD_ambiguity = 25/2 * eye(num_sv);
P_SD_multipath = eye(num_sv) * multipath_variance;
P_hat = blkdiag(P_delta_x, P_SD_rcvr_clk, P_SD_ambiguity, P_SD_multipath);

%-- Kalman filter matrices. 'A' is the state transition matrix, Q is the process noise covariance
%-- matrix, and R is the single-difference measurement noise covariance matrix.
A = blkdiag(eye(3), F_clk, eye(num_sv), eye(num_sv) * alpha);
Q = blkdiag(zeros(3), 2 * Q_clk, zeros(num_sv), eye(num_sv) * multipath_variance * (1 - alpha ^ 2));
R = eye(num_sv) * wgn_variance;

ind_start = 0;
counter = 0;
KF_covariance = zeros(total_num_epochs, 6);
PHMI_FF_i = zeros(total_num_epochs, 1);
sighat = zeros(total_num_epochs, 1);
%-- Filtering loop.
for TimeIndex = 1 : total_num_epochs
    disp(TimeIndex);
    %-- Line-of-sight vectors.
    ind_start = ind_start + 1;
    ind_end = TimeIndex * num_sv;
    E = LOS_unit_vector_ecef(ind_start : ind_end, :);

    %-- Time update.
    P_bar = A * P_hat * A' + Q;

    %-- Measurement update. 'C' is the observation matrix, 'N' is the innovation covariance
    %-- matrix and 'gamma' is the innovation vector.
    C = [E, ones(num_sv, 1), zeros(num_sv, 1), eye(num_sv), eye(num_sv)];
    N = C * P_bar * C' + R;
    K = P_bar * C' / N;
    Y = eye(num_KF_states) - K * C;
    P_hat = Y * P_bar * Y' + K * R * K';
        
    sighat(TimeIndex) = sqrt(alpVec' * P_hat * alpVec);

    if tVec(TimeIndex) >= tsCoast             % the previous time-step was externally protected
        if tVec(TimeIndex) == tsCoast
            iCoast = TimeIndex;
            PhatsubM = [];

            T_SS_i  = NaN(total_num_epochs, 1);
            PL_SS_i = NaN(total_num_epochs, 1);
            sighatSub_i = NaN(total_num_epochs, 1);
            PHMI_SS_i = NaN(total_num_epochs, 1);

            T_SSS_i  = NaN(total_num_epochs, total_num_epochs);
            T_MHSSS_i = NaN(total_num_epochs, total_num_epochs);
            sigbarFF_i = NaN(total_num_epochs, total_num_epochs);
            sighatSSSub_i = NaN(total_num_epochs, total_num_epochs);
            PHMI_MHSSS_i = zeros(total_num_epochs, 1);
            PHMI_SSS_cons = zeros(total_num_epochs, 1);

            T_SNIS_i = NaN(total_num_epochs, 1);
            PL_SNIS_i = NaN(total_num_epochs, 1);
            PHMI_SNISi = NaN(total_num_epochs, 1);

            Phatsub = P_bar;
            PhatSS = Phatsub - P_hat;

            PbarM = P_bar; % inv(eye(2) - K*H)*Phat; % Pbar;% downdate
            QM = P_bar - P_hat;
        else
            Phatsub = A * Phatsub * A' + Q;
            PhatSS = Phatsub - P_hat + A * PhatSS * A' + Q * 0;
            
            for ii = iCoast : TimeIndex - 1
                currInd = num_KF_states * (ii - iCoast) + 1 : num_KF_states * (ii - iCoast + 1);
                PbarM(:, currInd) = A * PbarM(:, currInd) * A' + Q;
                QM(:, currInd) = A * QM(:, currInd) * A' + P_bar - P_hat;
            end
            PbarM = [PbarM         P_bar]; %(:,end-1:end)
            QM = [QM      P_bar - P_hat];
            
            PhatSScheck = Phatsub - P_hat;
            % max(abs(PhatSScheck - PhatSS))
        end
        sighatSub_i(TimeIndex) = sqrt(alpVec' * Phatsub * alpVec);

        T_SS_i(TimeIndex) = kFA * sqrt(alpVec' * PhatSS * alpVec);
        PL_SS_i(TimeIndex) = kHMI * sighatSub_i(TimeIndex) + T_SS_i(TimeIndex);
        PHMI_SS_i(TimeIndex) = (TimeIndex - iCoast + 1) * sampling_interval * Ron * (normcdf(-AL - T_SS_i(TimeIndex), 0, sighatSub_i(TimeIndex)) +...
                                1 - normcdf(AL - T_SS_i(TimeIndex), 0, sighatSub_i(TimeIndex)));
        
        iii=0;
        for ii = iCoast : TimeIndex
            currInd = num_KF_states * (ii - iCoast) + 1 : num_KF_states * (ii - iCoast + 1);
            extVecM = zeros(num_KF_states * (TimeIndex - iCoast + 1), 1); extVecM(currInd) = alpVec;
            sigQvec = sqrt(alpVec' * QM * extVecM);
            sigEpsbarvec = sqrt(alpVec' * PbarM * extVecM);
            kFAMHSSS = norminv(1 - PFAreq / 2 / (ii - iCoast + 1));
            T_MHSSS_i(TimeIndex, ii) = kFAMHSSS * sigQvec;
            sigbarFF_i(TimeIndex, ii) = sigEpsbarvec;
            
            PHMI_MHSSS_i(TimeIndex) = PHMI_MHSSS_i(TimeIndex) + ...
                                      sampling_interval * Ron * (normcdf(-AL - T_MHSSS_i(TimeIndex, ii), 0, sigbarFF_i(TimeIndex, ii)) +...
                                      1 - normcdf(AL - T_MHSSS_i(TimeIndex, ii), 0, sigbarFF_i(TimeIndex, ii)));
            
        end
        % if 1 % flag_check
        %     currInd = 1 : 2;
        %     extVecM = zeros(2 * (TimeIndex - iCoast + 1), 2); extVecM(currInd, :) = eye(2);
        %     Pbar_kgj =  PbarM * extVecM;
        %     Q_kgj = QM * extVecM;
        %
        %     max(abs(Pbar_kgj - P_hat - Q_kgj))
        % end
        
        
        PHMI_SSS_cons(TimeIndex) = ...
            sampling_interval * Ron * (TimeIndex - iCoast + 1) * (normcdf(-AL - T_MHSSS_i(TimeIndex, iCoast), 0, sigbarFF_i(TimeIndex, iCoast)) +...
            1 - normcdf(AL - T_MHSSS_i(TimeIndex, iCoast), 0, sigbarFF_i(TimeIndex, iCoast)));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if TimeIndex == iCoast
            AK = K;
            BK = eye(num_sv);
            CK = BK;
            YY = N;
            AK0ld = AK;
        else
            AK = [(eye(num_KF_states) - K * C) * A * AK, K];
            BK = [-C * A * AK0ld, eye(num_sv)];
            AK0ld = AK;
            CK = [CK, zeros((TimeIndex - iCoast) * num_sv, num_sv);...
                  BK];
            YY = blkdiag(YY, N);
        end

        % fWC = inv(CK)*YY*inv(CK)'*AK'*alpVec;
        % wcSlope2check = fWC'*AK'*alpVec*alpVec'*AK*fWC/(fWC'*CK'*inv(YY)*CK*fWC)
        wcSlope2 = alpVec' * AK * inv(CK) * YY * inv(CK)' * AK' * alpVec;
        T_SNIS = chi2inv(1 - PFAreq, num_sv * (TimeIndex - iCoast + 1));
        NCP_SNIS = 0 : 0.1 : 5 * T_SNIS;

        meanError_SNIS = sqrt(wcSlope2 * NCP_SNIS);
        PHI_SNIS = normcdf(-AL, meanError_SNIS, sqrt(alpVec' * P_hat * alpVec)) +...
                   1 - normcdf(AL, meanError_SNIS, sqrt(alpVec' * P_hat * alpVec));
        PND_SNIS = ncx2cdf(T_SNIS, num_sv * (TimeIndex - iCoast + 1), NCP_SNIS);
        [PHMI_SNIS, ind] = max(PHI_SNIS .* PND_SNIS);
        if ind == length (NCP_SNIS),'attention';end

        T_SNIS_i(TimeIndex) = T_SNIS;
        PHMI_SNISi(TimeIndex) = sampling_interval * Ron * (TimeIndex - iCoast + 1) * PHMI_SNIS;
        
        PHMI_FF_i(TimeIndex) = (1 - (nT - iCoast + 1) * sampling_interval * Ron) * (normcdf(-AL, 0, sighat(TimeIndex)) +...
                                1 - normcdf(AL, 0, sighat(TimeIndex)));
    else
        PHMI_FF_i(TimeIndex) = (normcdf(-AL, 0, sighat(TimeIndex)) +...
                               1 - normcdf(AL, 0, sighat(TimeIndex)));
    end

    %-- Save results.
    counter = counter + 1;
    time = (TimeIndex - 1) * sampling_interval;
    KF_covariance(counter, :) = [time, sqrt(diag(P_hat(1 : 5, 1 : 5)))'];

    %-- Update the starting index for satellite geometry.
    ind_start = ind_end;
end
PHMI_SNISi = PHMI_SNISi + PHMI_FF_i;
PHMI_SSS_cons = PHMI_SSS_cons + PHMI_FF_i;
PHMI_MHSSS_i = PHMI_MHSSS_i + PHMI_FF_i;
PHMI_SS_i = PHMI_SS_i + PHMI_FF_i;

figure;
clf
% semilogy(tVec, PHMI_SS_i, '--', 'Linewidth', 1)
semilogy(tVec, PHMI_SNISi, 'k-', 'Color', [117, 120, 123]/255, 'Linewidth', 3);
hold on
semilogy(tVec, PHMI_SSS_cons, 'b-', 'Color', [229, 117, 31]/255, 'Linewidth', 3);
semilogy(tVec, PHMI_MHSSS_i, 'r-', 'Color', [134, 31, 65]/255, 'Linewidth', 5);
hold off
% legend('SS (wrong)',
legend('SNIS', 'SSS', 'MHSSS', 'Location', 'southeast');
xlabel('Time (e.g., in units of TTA)', 'FontSize', 18);
ylabel('Integrity Risk  ( P(HMI_k) )', 'FontSize', 18);
set(gca, 'YGrid', 'on', 'Xlim', [tVec(1) tVec(end)], 'Ylim', [1e-10 1]);
set(gca,'FontSize', 18);

% figure;
% subplot(3, 1, 1); hold on; grid on;
% plot(KF_est(:, 1), -sqrt(KF_covariance(:, 2)), 'r');
% plot(KF_est(:, 1), sqrt(KF_covariance(:, 2)), 'r');
%
% subplot(3, 1, 2); hold on; grid on;
% plot(KF_est(:, 1), -sqrt(KF_covariance(:, 3)), 'r');
% plot(KF_est(:, 1), sqrt(KF_covariance(:, 3)), 'r');
%
% subplot(3, 1, 3); hold on; grid on;
% plot(KF_est(:, 1), -sqrt(KF_covariance(:, 4)), 'r');
% plot(KF_est(:, 1), sqrt(KF_covariance(:, 4)), 'r');


% figure;
%     subplot(2, 1, 1); hold on; grid on;
%     plot(KF_est(:, 1), -sqrt(KF_covariance(:, 5)), 'r');
%     plot(KF_est(:, 1), sqrt(KF_covariance(:, 5)), 'r');
%     
%     subplot(2, 1, 2); hold on; grid on;
%     plot(KF_est(:, 1), -sqrt(KF_covariance(:, 6)), 'r');
%     plot(KF_est(:, 1), sqrt(KF_covariance(:, 6)), 'r');

% time_vector = (0 : 0.5 : 3600)';
% 
% figure('WindowState', 'Maximized', 'Color', 'White');
% hold on;
% p1 = plot(time_vector / 60, steve(:, 1), 'Color', 'k', 'LineStyle', '-', 'LineWidth', 1);
% p2 = plot(time_vector / 60, steve(:, 2), 'Color', 'k', 'LineStyle', '-', 'Marker', '.', 'MarkerSize', 16, ...
%           'MarkerIndices', [1:200:length(time_vector), length(time_vector)], 'LineWidth', 1);
% p3 = plot(time_vector / 60, steve(:, 3), 'Color', 'k', 'LineStyle', ':', 'LineWidth', 2);
% p4 = plot(time_vector / 60, steve(:, 4), 'Color', [0.65, 0.65, 0.65], 'LineStyle', '-', 'LineWidth', 1);
% line([0, 60], [1, 1], 'Color', 'k', 'LineStyle', '--', 'LineWidth', 1.5);
% 
% set(gca, 'linewidth', 1.5, 'fontsize', 14, 'box', 'on', 'TickLabelInterpreter', 'latex');
% ax_1 = gca;
% xlabel({'$\textrm{Elapsed time (minutes)}$', ' '}, 'fontsize', 14, 'Interpreter', 'latex');
% ylabel({'$\textrm{test statistic/threshold}$', ' '}, 'fontsize', 14, 'Interpreter', 'latex');
% ax_1.YLabel.VerticalAlignment = 'middle';
% xlim([0, 60]);
% ylim([0, 1.5]);
% 
% xticks(0 : 10 : 60);
% yticks(0 : 0.25 : 1.5);
% 
% legend([p1, p2, p3, p4], '$\textrm{SIM}$', '$\textrm{CIM}$', '$\textrm{CIM bank}$', '$\textrm{CUSUM}$', ...
%         'Location', 'northwest', 'fontsize', 14, 'NumColumns', 2, 'Interpreter', 'latex');

end

