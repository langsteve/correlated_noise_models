function [az, el] = NED2AZEL(ned)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function to convert a North, East, Down vector into azimuth and elevation.
%
%   Input:
%      ned - vector in north, east, and down coordinates (nx3)
%            (or could be used with any other coordinate system where north and east
%            are two local-level unit vectors such that north x east = down, e.g., an
%            aircraft navigation frame or a satellite local-level frame).
%   Output:
%      az  - azimuth (rad) (nx1): Rotation of vector in local North-East
%            plane, clockwise positive beginning at North,  0 <= az < 2*pi.
%      el  - elevation (rad) (nx1): Angle of vector above North-East plane,
%            positive for a vector with a negative down component   (i.e., 
%            positive up component), -pi/2 <= el <= pi/2.

% Azimuth is defined from north, therefore atan2(E/N)
az = atan2(ned(:, 2), ned(:, 1));    % in radians.   

% Convert azimuths to be between 0 and 2*pi.
I_neg_az = find(az < 0);
if ~isempty(I_neg_az)
    az(I_neg_az) = az(I_neg_az) + 2 * pi;
end

% elevation is defined from the local level (N-E) plane positive in the up (-D) direction.
north_east_mag = sqrt(ned(:, 1) .^ 2 + ned(:, 2) .^ 2);  % Magnitude in the N-E plane
el = atan2(-ned(:, 3), north_east_mag);                  % elevation (rad).

end