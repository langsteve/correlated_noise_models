function [t_out, prn, x, v] = PROPGEPH(gps_ephem, t_start, t_stop, dt)

%-------------------------------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and U.S. DoD contractors only
% (critical technology)(June 26, 2019). Other requests shall be referred to (PNT Program Office).
%-------------------------------------------------------------------------------------------------------------

%-------------------------------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No. FA8702-19-C-0001, and is subject to
% the Rights in Noncommercial Computer Software and Noncommercial Computer Software Documentation Clause
% 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%-------------------------------------------------------------------------------------------------------------


% [t_out, prn, x, v] = propgeph(gps_ephem, t_start, t_stop, dt);
%
% Computes satellite positions in ECEF coordinates from a GPS ephemeris.
%
% Input:
%   gps_ephem - Ephemeris matrix for all satellites (nx24), with columns of:
%               [prn, M0, delta_n, e, sqrt_a, long. of asc_node at GPS week epoch,
%               i, perigee, ra_rate, i_rate, Cuc, Cus, Crc, Crs, Cic, Cis, Toe,
%               IODE, GPS_week, Toc, Af0, Af1, Af2, perigee_rate] 
%               Ephemeris parameters are from ICD-GPS-200 with the exception of
%               perigee_rate.

%   t_start   - Start time in GPS format (1x2) or (nx2) [GPS_week GPS_sec]. If t_stop
%               is not provided, orbits will be computed at each of the t_start times.
%               Must be 1x2 if t_stop is given. Valid GPS_week values are 1-3640
%               (years 1980-2050). Valid GPS_sec values are 0-604799.

%   t_stop    - Stop time in GPS time format (1x2) [GPS_week GPS_sec].

%   dt        - Output interval in seconds.
%
% Output:
%   t_out     - GPS time vector output [GPS_week, GPS_sec] (nx2).
%   prn       - S/C (PRN) number (nx1).
%   x         - S/C position in ECEF meters (nx3).
%   v         - S/C velocity in ECEF meters/second (nx3).
%
% Note: Output are in time order with all of the satellites at time #1 first,
%       followed by the satellites at time #2, etc.  The position and velocity
%       correspond to the times and satellite numbers in the corresponding columns.
%       The t_out and prn matrices have the following form
%                           wk  s  prn   X    Y    Z    Vx    Vy    Vz
%        [t_out prn x v] = [933 1   1   x11  y11  z11  vx11  vy11  vz11
%                           933 1   2   x12  y12  z12  vx12  vy12  vz12
%                            .      .    .    .    .     .     .     .
%                            .      .    .    .    .     .     .     .
%                           933 1   24  x124 y124 z124 vx124 vy124 vz124
%                           933 2   1   x21  y21  z21  vx21  vy21  vz21
%                           933 2   2   x22  y22  z22  vx22  vy22  vz22
%                            .      .    .    .    .     .     .     .
%                           933 600 24   .    .    .     .     .     .  ]
%

% This is taken directly from
% "Global Positioning System: Theory and Applications", Parkinson and Spilker,
% Vol. 1, pages 132-138 with the equation for x(:,2) (yk in Table 8) corrected.

% functions called: KEPLR_EQ

% WGS-84 constants
MU_EARTH = 3.986005e14;       % WGS-84 value in m^3/s^2
EARTH_RATE = 7.2921151467e-5; % WGS-84 value in rad/s

% Find the earliest starting week in the ephemeris data and start data.
week_min = min([min(gps_ephem(:, 19)) t_start(1)]);

% Compute the start and stop times.
stop_time_seconds = (t_stop(1) - week_min) * 86400 * 7 + t_stop(2); 
start_time_seconds = (t_start(1) - week_min) * 86400 * 7 + t_start(2); 

% Build the linear time series.
t_input = (start_time_seconds : dt : stop_time_seconds);

% Search the prn column and see how many satellites are in the ephemeris.
for i = 1 : size(gps_ephem, 1)
    prn(i) = gps_ephem(i, 1);
end

num_active_satellites = length(prn);   % We know we have at most this many.

% Find the number of time steps to be evaluated.
num_time_steps = size(t_input, 2);  

% Get total size for memory allocation.
total_size = num_time_steps * num_active_satellites; 

% Allocate output matrix space.
x = ones(total_size, 3) * NaN;
v = ones(total_size, 3) * NaN;
t_out = ones(total_size, 2) * NaN;
prn = ones(total_size, 1) * NaN; 

for jjj = 1 : num_active_satellites
    output_index = (jjj : num_active_satellites : total_size); % Indices for output.
  
    % Convert the ephemeris epoch into the same time scale used elsewhere (sec past min. week).
    ephemeris_epoch = (gps_ephem(jjj, 19) - week_min) * 86400 * 7 + ...
                       gps_ephem(jjj, 17);
    t = t_input - ephemeris_epoch;   % Time past ephemeris epoch. Toe = gps_ephem(:, 17).
    a = gps_ephem(jjj, 5) .^ 2;      % Compute a, sqrt(a) = gps_ephem(:, 5) (m).
    e = gps_ephem(jjj, 4);           % Load eccentricity to a local variable.
    n0 = sqrt(MU_EARTH / a .^ 3);    % Compute the nominal mean motion (rad/s).
    n = n0 + gps_ephem(jjj, 3);      % Corrected mean motion. delta_n = gps_ephem(:, 3).
    M = gps_ephem(jjj, 2) + n .* t;  % Compute mean anomaly, M0 = gps_ephem(:, 2).

    % load perigee to a local variable and add perigee rate
    perigee  = gps_ephem(jjj, 8) + gps_ephem(jjj, 24) .* t;      

    % Check input values of e to verify it is an eccentric orbit.
    clear I
    I = find(e > .6);
    if any(I)
        fprintf('Warning message from propgeph.m ...\n')
        fprintf('Results may be in error for eccentricities greater than 0.6.\n')
        fprintf('This propagator is not designed for parabolic or hyperbolic orbits.\n')
        fprintf('Results may be invalid.  e = %f.\n \n',e(I) )
    end
  
    % Solve Kepler's eq for eccentric anomaly (E) from M = E - e sin(E).
    E = KEPLR_EQ(M, e);
  
    % Compute true anomaly.
    nu = atan2(sqrt(1 - e .^ 2) .* sin(E) ./ (1 - e .* cos(E)), ...
               (cos(E) - e) ./ (1 - e .* cos(E))); 

    % Compute the argument of latitude.
    phi = nu + perigee;

    % Compute corrections to argument of latitude.

    % Compute sinusoidal terms from the ephemeris data
    del_u = gps_ephem(jjj, 12) .* sin(2 .* phi) + ...  % Cus = gps_ephem(jjj, 12).
            gps_ephem(jjj, 11) .* cos(2 .* phi);       % Cuc = gps_ephem(jjj, 11).
              
    del_r = gps_ephem(jjj, 14) .* sin(2 .* phi) + ...  % Crs = gps_ephem(jjj, 14).
            gps_ephem(jjj, 13) .* cos(2 .* phi);       % Crc = gps_ephem(jjj, 13).
           
    del_i = gps_ephem(jjj, 16) .* sin(2 .* phi) + ...  % Cis = gps_ephem(jjj, 16).
            gps_ephem(jjj, 15) .* cos(2 .* phi);       % Cic = gps_ephem(jjj, 15).

    u = phi + del_u;                      % Argument of latitude correction.
    r = a .* (1 - e .* cos(E)) + del_r;   % Radius correction. 

    % Inclination correction.   i = gps_ephem(jjj, 7) and i_rate = gps_ephem(jjj, 10).
    i = gps_ephem(jjj, 7) + del_i + gps_ephem(jjj, 10) .* t; 

    xo = (r .* cos(u))';    % Satellite x-position in orbital plane.
    yo = (r .* sin(u))';    % Satellite y-position in orbital plane.

    % Corrected longitude of ascending node for node rate and Earth rotation Asc node = gps_ephem(jjj, 6) and
    % node rate = gps_ephem(jjj, 9).
    node = gps_ephem(jjj, 6) + (gps_ephem(jjj, 9) - EARTH_RATE) .* t -  ...
           EARTH_RATE * gps_ephem(jjj, 17);   % Toe = gps_ephem(jjj, 17).

    % Satellite x-position in ECEF (m).
    x(output_index, 1) = xo .* cos(node') - yo .* cos(i') .* sin(node');    
    % Satellite y-position in ECEF (m).
    x(output_index, 2) = xo .* sin(node') + yo .* cos(i') .* cos(node');    
    % Satellite z-position in ECEF (m).
    x(output_index, 3) = yo .* sin(i');                                     

    % Compute satellite velocity in the perifocal coordinate system, from Bate, Mueller, & White pp. 73 & 82.
    r = sqrt(x(output_index, 1) .^ 2 + x(output_index, 2) .^ 2 + ...
             x(output_index, 3) .^ 2);
  
    p = r .* (1 + e .* cos(nu'));

    vp = -sqrt(MU_EARTH ./ p) .* sin(nu');
    vq = sqrt(MU_EARTH ./ p) .* (e + cos(nu'));

    % Inertial velocity vector in ECEF coordinates.
    v(output_index, 1) = vp .* (cos(node') .* cos(perigee') - sin(node') .* sin(perigee') .* cos(i')) + ...
                         vq .* (-cos(node') .* sin(perigee') - sin(node') .* cos(perigee') .* cos(i')); 
    v(output_index, 2) = vp .* (sin(node') .* cos(perigee') + cos(node') .* sin(perigee') .* cos(i')) + ...
                         vq .* (-sin(node') .* sin(perigee') + cos(node') .* cos(perigee') .* cos(i'));
    v(output_index, 3) = vp .* sin(perigee') .* sin(i') + vq .* cos(perigee') .* sin(i');          
  
    prn(output_index) = ones(size(output_index)) * gps_ephem(jjj, 1);
    t_out(output_index, 2) = t_input';
                                                                                       
end

if ~any(t_out)
    fprintf('Error message from propgeph.m\n')
    fprintf('No active satellite found.\n')
    fprintf('Possible invalid return arguments. Check inputs.\n\n')
    return
end

% Compute omega cross r term for use in converting from ECEF to inertial velocities.
e_rate_ecef = [0 0 EARTH_RATE]' * ones(1, size(x, 1));
o_cross_r = cross(e_rate_ecef, x')';

% Convert to ECEF velocity by removing the omega cross r term.
v = v - o_cross_r;        

% Reformat the time matrix (get it back into GPS time).

% Fill in the time matrix with this week value.
t_out(:, 1) = ones(size(t_out, 1), 1) * week_min; 

I_roll = find(t_out(:, 2) >= 86400 * 7);  % Check for and find week roll-overs.
                                                   
if any(I_roll)   % If there is (are) a roll-over(s), convert it to weeks.
    % fix the week
    t_out(I_roll, 1) = t_out(I_roll, 1) + fix(t_out(I_roll, 2) ./ (86400 * 7));    
    % fix the seconds
    t_out(I_roll, 2) = rem(t_out(I_roll, 2), (86400 * 7));                        
end
