close all
clear all

% for a finite window, compare 
% the SS bound covering the entire window
% the SS bound covering fractions of the bound with corresponding priors
% 
% question:  how much does PL decrease if you just change the prior?

% in prior work, we showed that, 
% instant redundancy (residual vs SS):  
% MH: tailored to fault
% SS: tailored to state
% temporal redundancy over time
%  Projected Innovations tailored to state of
% interest 
% SS has the added advantage that you can bound


draw_intermediate_plots = 0;    % 1 = draw plots in loop, 0 = don't

nz = 1;                         % number of measurements
Ron = 0.00001;                      % rate of onset per unit time   

Dt = 1;    %.1                   % sampling interval
tVec = 0:Dt:60; %30                % time vector
tsCoast = 2; %1                   % start time of exposure

sigVeta = 1;                    % measurement noise error standard deviation
sigWx = 1;                      % x-process noise standard deviation
sigWv = .01;                      % v-process noise standard deviation

Phi = [1, Dt; 0, 1];            % process matrix (STM)
W = diag([sigWx^2, sigWv^2]);   % process noise matrix
nx = size(Phi,1);               % number of states
H = [ones(nz,1), zeros(nz,1)];  % measurement matrix
V = diag(ones(nz,1))*sigVeta^2; % measurement noise covariance matrix

% alpVec = [0; 1];                % state of interest (Velocity)
alpVec = [1; 0];                % state of interest (Position)
'check velocity again'
AL = 150;                        % alert limit on state of interest
if alpVec(2) == 1
    AL = 10;
end
PFAreq = 1e-4;
PHMIreq = 1e-5;
kFA = norminv(1 - PFAreq/2);
kHMI = norminv(1 - PHMIreq/2);

big = 1e6;
Pbar0 = big*eye(nx);
nT = length(tVec);
sigX_i = zeros(nT,1);
sigV_i = zeros(nT,1);
PHMI_FF_i = zeros(nT,1);
sighat = zeros(nT,1);
for i = 1 : nT
    if i==1
        Pbar = Pbar0;
    end
    K = Pbar*H'*inv(H*Pbar*H' + V);
    Phat = (eye(nx) - K*H)*Pbar*(eye(nx) - K*H)'+K*V*K'; %     Phat = (eye(3+n-1) - K*H)*Pbar;
    Y = H*Pbar*H' + V;
    
    sighat(i) = sqrt(alpVec'*Phat*alpVec);

    if tVec(i) >= tsCoast             % the previous time-step was externally protected
        if tVec(i) == tsCoast
            iCoast = i;
            PhatsubM = [];

            T_SS_i  = NaN(nT,1);
            PL_SS_i = NaN(nT,1);
            sighatSub_i = NaN(nT,1);
            PHMI_SS_i = NaN(nT,1);

            T_SSS_i  = NaN(nT,nT);
            T_MHSSS_i = NaN(nT,nT);
            sigbarFF_i = NaN(nT,nT);
            sighatSSSub_i = NaN(nT,nT);
            PHMI_MHSSS_i = zeros(nT,1);
            PHMI_SSS_cons = zeros(nT,1);
            
            T_SNIS_i = NaN(nT,1);
            PL_SNIS_i = NaN(nT,1);
            PHMI_SNISi = NaN(nT,1);
            
            Phatsub = Pbar;
            PhatSS = Phatsub - Phat;

            PbarM = Pbar; % inv(eye(2) - K*H)*Phat; % Pbar;% downdate
            QM = Pbar - Phat;
        else
            Phatsub = Phi*Phatsub*Phi' + W;
            PhatSS = Phatsub - Phat + Phi*PhatSS*Phi' + W*0;
            
            for ii = iCoast:i-1
                currInd = 2*(ii-iCoast)+1:2*(ii-iCoast+1);
                PbarM(:,currInd) = Phi*PbarM(:,currInd)*Phi'+W;
                QM(:,currInd) = Phi*QM(:,currInd)*Phi'+ Pbar - Phat;
            end
            PbarM = [PbarM         Pbar]; %(:,end-1:end)
            QM = [QM      Pbar - Phat];
            
            PhatSScheck = Phatsub - Phat;
            %max(abs(PhatSScheck - PhatSS))
        end
        sighatSub_i(i) = sqrt(alpVec' * Phatsub * alpVec);

        T_SS_i(i) = kFA * sqrt(alpVec' * PhatSS * alpVec);
        PL_SS_i(i) = kHMI * sighatSub_i(i) + T_SS_i(i);
        PHMI_SS_i(i) = (i-iCoast+1)*Dt*Ron*(normcdf(-AL - T_SS_i(i), 0, sighatSub_i(i)) +...
            1 - normcdf(AL - T_SS_i(i), 0, sighatSub_i(i)));
        
        iii=0;
        for ii = iCoast:i
            currInd = 2*(ii-iCoast)+1:2*(ii-iCoast+1);
            extVecM = zeros(2*(i-iCoast+1),1); extVecM(currInd)=alpVec;
            sigQvec = sqrt(alpVec' * QM * extVecM);
            sigEpsbarvec = sqrt(alpVec' * PbarM * extVecM);
            kFAMHSSS = norminv(1 - PFAreq/2/(ii-iCoast+1));
            T_MHSSS_i(i,ii) = kFAMHSSS * sigQvec;
            sigbarFF_i(i,ii) = sigEpsbarvec;
            
            PHMI_MHSSS_i(i) = PHMI_MHSSS_i(i) + ...
                Dt*Ron*(normcdf(-AL - T_MHSSS_i(i,ii), 0, sigbarFF_i(i,ii)) +...
                1 - normcdf(AL - T_MHSSS_i(i,ii), 0, sigbarFF_i(i,ii)));
            
        end
        if 1 % flag_check
            currInd = 1:2;
            extVecM = zeros(2*(i-iCoast+1),2); extVecM(currInd,:)=eye(2);
            Pbar_kgj =  PbarM * extVecM;
            Q_kgj = QM * extVecM;
            
            max(abs(Pbar_kgj-Phat - Q_kgj))
        end
        
        
        PHMI_SSS_cons(i) = ...
            Dt*Ron*(i-iCoast+1)*(normcdf(-AL - T_MHSSS_i(i,iCoast), 0, sigbarFF_i(i,iCoast)) +...
            1 - normcdf(AL - T_MHSSS_i(i,iCoast), 0, sigbarFF_i(i,iCoast)));
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
        if i == iCoast
            AK = K;
            BK = eye(nz);
            CK = BK;
            YY = Y;
            AK0ld = AK;
        else
            AK = [(eye(nx) - K*H)*Phi*AK, K];
            BK = [-H*Phi*AK0ld, eye(nz)];
            AK0ld = AK;
            CK = [CK, zeros((i - iCoast)*nz, nz);...
                BK];
            YY = blkdiag(YY, Y);
        end

        % fWC = inv(CK)*YY*inv(CK)'*AK'*alpVec;
        % wcSlope2check = fWC'*AK'*alpVec*alpVec'*AK*fWC/(fWC'*CK'*inv(YY)*CK*fWC)
        wcSlope2 = alpVec'*AK*inv(CK)*YY*inv(CK)'*AK'*alpVec;
        T_SNIS = chi2inv(1 - PFAreq, nz*(i - iCoast + 1));
        NCP_SNIS = 0:0.1:5*T_SNIS;
        if alpVec(2)
            NCP_SNIS = 0:0.1:2*T_SNIS;
        end
        meanError_SNIS = sqrt(wcSlope2 * NCP_SNIS);
        PHI_SNIS = normcdf(-AL, meanError_SNIS, sqrt(alpVec'*Phat*alpVec)) +...
            1 - normcdf(AL, meanError_SNIS, sqrt(alpVec'*Phat*alpVec));
        PND_SNIS = ncx2cdf(T_SNIS, nz*(i-iCoast+1), NCP_SNIS);
        [PHMI_SNIS, ind] = max(PHI_SNIS.*PND_SNIS);
        if ind == length (NCP_SNIS),'attention';end

        T_SNIS_i(i) = T_SNIS;
        PHMI_SNISi(i) = Dt*Ron*(i-iCoast+1)*PHMI_SNIS;
        
        PHMI_FF_i(i) = (1-(nT-iCoast+1)*Dt*Ron)*(normcdf(-AL, 0, sighat(i)) +...
                    1 - normcdf(AL, 0, sighat(i)));
    else
        PHMI_FF_i(i) = (normcdf(-AL, 0, sighat(i)) +...
                    1 - normcdf(AL, 0, sighat(i)));
    end
    Pbar = Phi*Phat*Phi' + W;

    sigX_i(i)  = sqrt(Phat(1,1));
    sigV_i(i)  = sqrt(Phat(2,2));
end
PHMI_SNISi = PHMI_SNISi + PHMI_FF_i;
PHMI_SSS_cons = PHMI_SSS_cons + PHMI_FF_i;
PHMI_MHSSS_i = PHMI_MHSSS_i + PHMI_FF_i;
PHMI_SS_i = PHMI_SS_i + PHMI_FF_i;

%%
figure(1)
hold off
semilogy(tVec, sigX_i, 'Linewidth', 2)
hold on
semilogy(tVec, sigV_i, 'Linewidth', 2)
semilogy(tVec, T_SS_i, '-o', 'Linewidth', 2)
hold off
legend('position deviation','velocity deviation','T_{SS}')
xlabel('Time (h)')
ylabel('Standard Deviations (m & m/s)')
%set(gca,'YLim', [0 15])
grid on
%%
figure(11)
hold off
semilogy(tVec, sigX_i, 'Linewidth', 2)
hold on
semilogy(tVec, sigV_i, 'Linewidth', 2)
semilogy(tVec, T_SS_i, '-', 'Linewidth', 1)
semilogy(tVec, T_SSS_i', ':', 'Linewidth', 1)
hold off
legend('position deviation','velocity deviation','T_{SS}')
xlabel('Time (h)')
ylabel('Standard Deviations (m & m/s)')
%set(gca,'YLim', [0 15])
grid on

% figure(2)
% hold on
% plot(tVec, PL_SS_i, '-', 'Linewidth', 2)
% plot(tVec, T_SS_i, '-', 'Linewidth', 2)
% plot(tVec, sighatSub_i, '-', 'Linewidth', 2)
% 
% hold off
% legend('PL_{SS}','Ti_{SS}','sigEps_{(i)}',...
%     'location','best')
% xlabel('Time (h)')
% ylabel('PL, T, Standard Deviations')
% grid on
% % set(gca,'YLim',[0 5])

%%
figure(3)
clf
% semilogy(tVec, PHMI_SS_i, '--', 'Linewidth', 1)
semilogy(tVec, PHMI_SNISi, 'k-', 'Color',[117, 120, 123]/255,'Linewidth', 3)
hold on
semilogy(tVec, PHMI_SSS_cons, 'b-','Color',[229, 117, 31]/255, 'Linewidth', 3)
semilogy(tVec, PHMI_MHSSS_i, 'r-', 'Color',[134, 31, 65]/255,'Linewidth', 5)
hold off
% legend('SS (wrong)',
legend('SNIS','SSS','MHSSS','Location','southeast')
xlabel('Time (e.g., in units of TTA)','FontSize',18)
ylabel('Integrity Risk  ( P(HMI_k) )','FontSize',18)
set(gca,'YGrid','on','Xlim',[tVec(1) tVec(end)],'Ylim',[1e-10 1])
set(gca,'FontSize',18)

%%
return
figure(4)
subplot(2,1,1)
plot(tVec, PHMI_MHSSS_i./PHMI_SS_i, 'k-', 'Linewidth', 2)
legend('improvement factor','Location','southeast')
xlabel('Time (h)')
ylabel('risk ratio')
% set(gca,'YGrid','on','Xlim',[tVec(1) tVec(end)],'Ylim',[1e-13 1])
subplot(2,1,2)
plot(tVec, log10(PHMI_SS_i - PHMI_MHSSS_i), 'k-', 'Linewidth', 2)
legend('log difference','Location','southeast')
xlabel('Time (h)')
ylabel('risk difference (log)')
