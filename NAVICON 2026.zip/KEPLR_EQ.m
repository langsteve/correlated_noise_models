function E = KEPLR_EQ(M, e)

%------------------------------------------------------------------------------------
% DISTRIBUTION STATEMENT D. Distribution authorized to the Department of Defense and
% U.S. DoD contractors only (critical technology)(June 26, 2019). Other requests
% shall be referred to (PNT Program Office).
%------------------------------------------------------------------------------------

%------------------------------------------------------------------------------------
% NOTICE
% This software was produced for the U.S. Government under Contract No.
% FA8702-19-C-0001, and is subject to the Rights in Noncommercial Computer Software
% and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2014).

% Copyright 2019 The MITRE Corporation. All Rights Reserved.
%------------------------------------------------------------------------------------


% Function (vectorized) to iteratively solve Kepler's equation for eccentric anomaly.
%
% Input:
%   M - mean anomaly (rad) (nxm)
%   e - eccentricity (dimensionless) (nxm) or (1x1)
% Output:
%   E - eccentric anomaly (rad) (nxm)

% Set convergence criterion.
tol = 1e-12;      % Convergence criterion.
max_iter = 10;    % Max iteration. 

m = 1;            % Iteration counter initial value.
dE = 1.0;         % Set initial value of delta-E to fail convergence.

E = M + (e .* sin(M)) ./ (1 - sin(M + e) + sin(M));    % Set initial value of E.
while (any(find(dE > tol)) && m <= max_iter)
    dE = (E - e .* sin(E) - M) ./ (1 - e .* cos(E));
    E = E - dE;         % Update E.
    m = m + 1;          % Increment iteration counter.

    if m > max_iter     % check against maximum iterations allowed
        fprintf('Warning message from KEPLR_EQ ...\n')
        fprintf('Maximum iterations exceeded in solution of Kepler''s Equation.\n')
        fprintf('Results may be invalid.\n\n', e)
        return
    end

end

end

